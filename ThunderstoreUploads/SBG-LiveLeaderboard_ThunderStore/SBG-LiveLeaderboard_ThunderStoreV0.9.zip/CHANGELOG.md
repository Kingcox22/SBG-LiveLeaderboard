## 0.9
* Initial release.
* Added Live Leaderboard logic.
* Added distance to the UI since that is how we are calculating position.
