## 1.0.2
* Future Proofing (No Visible Changes)
## 1.0.1
* Reworked logic to be more reliable.
* Added logic to track ball distance from the flag.
## 0.9
* Initial release.
* Added Live Leaderboard logic.
* Added distance to the UI since that is how we are calculating position.

