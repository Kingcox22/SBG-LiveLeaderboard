## 1.0.1
* Reworked logic to be more reliable.
* Added logic to track ball distance from the flag.

